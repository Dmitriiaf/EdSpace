package com.example.demo.repository;

import com.example.demo.entity.InvitationToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface InvitationTokenRepository extends JpaRepository<InvitationToken, Long> {
    Optional<InvitationToken> findByToken(String token);
    Optional<InvitationToken> findByEmailAndUserTypeAndUsedFalse(String email, String userType);

    void deleteByStudentId(Long studentId);
}
