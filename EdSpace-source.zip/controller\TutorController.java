package com.example.demo.controller;

import com.example.demo.entity.Tutor;
import com.example.demo.service.TutorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import lombok.extern.slf4j.Slf4j;
import java.util.List;
import java.util.Map;

@Slf4j
@RestController
@RequestMapping("/api/tutors")
@CrossOrigin(origins = "http://localhost:3000")
public class TutorController {

    @Autowired
    private TutorService tutorService;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String, String> request) {
        try {
            Tutor tutor = tutorService.registerTutor(
                    request.get("email"),
                    request.get("password"),
                    request.get("fullName"),
                    request.get("phone"),
                    request.getOrDefault("timezone", "Asia/Krasnoyarsk")
            );
            return ResponseEntity.ok(tutor);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> request) {
        try {
            Tutor tutor = tutorService.login(
                    request.get("email"),
                    request.get("password")
            );

            tutor.setPasswordHash(null);

            return ResponseEntity.ok(Map.of(
                    "message", "Вход выполнен успешно",
                    "tutor", tutor
            ));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getTutorById(@PathVariable Long id) {
        try {
            Tutor tutor = tutorService.getTutorById(id);
            tutor.setPasswordHash(null);
            return ResponseEntity.ok(tutor);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> updateTutor(@PathVariable Long id,
                                         @RequestBody Map<String, String> request) {
        try {
            Tutor tutor = tutorService.updateTutor(
                    id,
                    request.get("phone"),
                    request.get("fullName"),
                    request.get("birthday"),
                    request.get("about"),
                    request.get("city")
            );

            // Новые поля анкеты
            if (request.containsKey("subjects")) tutor.setSubjects(request.get("subjects"));
            if (request.containsKey("studentsCount")) tutor.setStudentsCount(request.get("studentsCount"));
            if (request.containsKey("experience")) tutor.setExperience(request.get("experience"));
            if (request.containsKey("source")) tutor.setSource(request.get("source"));
            if (request.containsKey("onboardingCompleted")) tutor.setOnboardingCompleted(Boolean.parseBoolean(request.get("onboardingCompleted")));
            if (request.containsKey("password") && request.get("password") != null && !request.get("password").isEmpty()) {
                tutor.setPasswordHash(tutorService.hashPassword(request.get("password")));
            }
            tutorService.save(tutor);

            tutor.setPasswordHash(null);
            return ResponseEntity.ok(tutor);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // ✅ ДОБАВИТЬ ЭТОТ МЕТОД - получение аватара
    @GetMapping("/{id}/avatar")
    public ResponseEntity<?> getAvatar(@PathVariable Long id) {
        try {
            Tutor tutor = tutorService.getTutorById(id);
            String avatar = tutor.getAvatar();
            log.debug("Запрос аватара для tutor ID: {}", id);
            log.debug("Avatar в БД: {}", avatar != null ? "есть" : "нет");
            // ✅ Исправлено: если avatar == null, возвращаем пустую строку
            return ResponseEntity.ok(Map.of("avatar", avatar != null ? avatar : ""));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteTutor(@PathVariable Long id) {
        try {
            tutorService.deleteTutor(id);
            return ResponseEntity.ok(Map.of("message", "Аккаунт успешно удалён"));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/{id}/export-data")
    public ResponseEntity<?> exportData(@PathVariable Long id) {
        try {
            Map<String, Object> data = tutorService.exportUserData(id);
            return ResponseEntity.ok(data);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/{id}/avatar")
    public ResponseEntity<?> uploadAvatar(@PathVariable Long id,
                                          @RequestBody Map<String, String> request) {
        try {
            String avatar = request.get("avatar");
            if (avatar == null || avatar.isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("error", "Аватар не может быть пустым"));
            }
            // Проверка размера (base64, примерно)
            if (avatar.length() > 500 * 1024) {
                return ResponseEntity.badRequest().body(Map.of("error", "Изображение слишком большое. Максимум 500KB"));
            }
            tutorService.updateAvatar(id, avatar);
            return ResponseEntity.ok(Map.of("message", "Фото успешно загружено"));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/{id}/change-password")
    public ResponseEntity<?> changePassword(@PathVariable Long id,
                                            @RequestBody Map<String, String> request) {
        try {
            tutorService.changePassword(
                    id,
                    request.get("currentPassword"),
                    request.get("newPassword")
            );
            return ResponseEntity.ok(Map.of("message", "Пароль успешно изменён"));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    // ✅ VIDEO-1: Обновление настроек видеоплатформы
    @PutMapping("/{id}/video-settings")
    public ResponseEntity<?> updateVideoSettings(@PathVariable Long id,
                                                 @RequestBody Map<String, String> request) {
        try {
            Tutor tutor = tutorService.getTutorById(id);
            if (request.containsKey("videoPlatform")) {
                tutor.setVideoPlatform(request.get("videoPlatform"));
            }
            if (request.containsKey("videoPlatformLink")) {
                tutor.setVideoPlatformLink(request.get("videoPlatformLink"));
            }
            tutorService.save(tutor);
            return ResponseEntity.ok(Map.of(
                    "message", "Настройки видео обновлены",
                    "videoPlatform", tutor.getVideoPlatform(),
                    "videoPlatformLink", tutor.getVideoPlatformLink()
            ));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping
    public ResponseEntity<List<Tutor>> getAllTutors() {
        List<Tutor> tutors = tutorService.getAllTutors();
        tutors.forEach(t -> t.setPasswordHash(null));
        return ResponseEntity.ok(tutors);
    }

    // ========== РЕФЕРАЛЬНАЯ СТАТИСТИКА ==========

    @GetMapping("/{id}/referral-stats")
    public ResponseEntity<?> getReferralStats(@PathVariable Long id) {
        try {
            Tutor tutor = tutorService.getTutorById(id);
            Map<String, Object> stats = tutorService.getReferralStats(id);
            stats.put("referralCode", tutor.getReferralCode());
            stats.put("referralLink", "https://ed-space.ru/register?ref=" + tutor.getReferralCode());
            return ResponseEntity.ok(stats);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

}